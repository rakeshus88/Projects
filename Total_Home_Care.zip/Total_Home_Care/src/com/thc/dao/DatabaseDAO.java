package com.thc.dao;
 

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;


public class DatabaseDAO {

	
	public static Connection getConnection() throws Exception {
		Connection dbConn = null;
		try {
			// step1:
			Class.forName("com.mysql.jdbc.Driver");
			// step2
			String url = "jdbc:mysql://localhost:3306/totalhomecare";

			// step3
		dbConn = DriverManager.getConnection(url, "root", "admin");
			
			System.out.println("Connection Successful");
		
			return dbConn;
		} catch (SQLException e) {
			 System.out.println(e.getMessage());
		
		}
		return dbConn;
	}
	

}
