package com.thc.web;

import java.sql.SQLException;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.thc.bo.LoginService;
import com.thc.bo.RegistrationService;
import com.thc.vo.LoginForm;
import com.thc.vo.RegistrationForm;

@Controller
public class LoginController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String loginForm(ModelMap model) {
		LoginForm lform = new LoginForm();
		model.addAttribute("lform", lform);
		return "home";

	}
	
	@RequestMapping(value = "/logininfo", method = RequestMethod.POST)
	public String getloginForm(@ModelAttribute("lform") @Valid LoginForm lform, BindingResult result, ModelMap model) throws SQLException {
       
		System.out.println("The name is : " + lform.getUsername());
		System.out.println("The Password is : " + lform.getPassword());
		System.out.println("I am here!!");
		if (result.hasErrors()) {
			return "home";
		}
		LoginService loginService = new LoginService();
		lform.setUsername(lform.getUsername());
		lform.setPassword(lform.getPassword());
		int status = loginService.checkLogin(lform);
		//String status = String.valueOf(stat);
		System.out.println("This is my current statsuu" +status);
		if(status == 1)
		{
			return "products";
		}
		else
		{
			 
			 model.addAttribute("message", "Invalid credentials!! Please use correct Login Details");
			
			return "home";
		}
		
	}
	
	@RequestMapping(value = "/shopLocation", method = RequestMethod.POST)
	public String findshopLocation (){
		return "locations";
		
	}
	
	@RequestMapping(value = "/fremontShoppingList", method = RequestMethod.POST)
	public String fremontshoppingComplex (){
		return "fremontshop";
		
	}
	@RequestMapping(value = "/cupertinoShoppingList", method = RequestMethod.POST)
	public String cupertinoshoppingComplex (){
		return "cupertinoshop";
		
	}
	@RequestMapping(value = "/losangelesShoppingList", method = RequestMethod.POST)
	public String losangelesshoppingComplex (){
		return "losangelesshop";
		
	}
	@RequestMapping(value = "/sanfranciscoShoppingList", method = RequestMethod.POST)
	public String sanfransiscoshoppingComplex (){
		return "sanfransiscoshop";
		
	}
	@RequestMapping(value = "/sunnyvaleShoppingList", method = RequestMethod.POST)
	public String sunnyvaleshoppingComplex (){
		return "sunnyvaleshop";
		
	}
	@RequestMapping(value = "/hotelLocation", method = RequestMethod.POST)
	public String findhotelLocation (){
		return "hotellocations";
		
	}
	
	@RequestMapping(value = "/fremontHotelList", method = RequestMethod.POST)
	public String fremontHotels (){
		return "fremonthotel";
		
	}
	@RequestMapping(value = "/cupertinoHotelList", method = RequestMethod.POST)
	public String cupertinoHotels (){
		return "cupertinohotel";
		
	}
	
	@RequestMapping(value = "/losangelesHotelList", method = RequestMethod.POST)
	public String losangelesHotels (){
		return "losangeleshotel";
		
	}
	@RequestMapping(value = "/sanfransiscoHotelList", method = RequestMethod.POST)
	public String sanfransiscoHotels (){
		return "sanfransiscohotel";
		
	}
	@RequestMapping(value = "/sunnyvaleHotelList", method = RequestMethod.POST)
	public String sunnyvaleHotels (){
		return "sunnyvalehotel";
		
	}
	@RequestMapping(value = "/pharmacy", method = RequestMethod.POST)
	public String findpharmacyLocation (){
		return "pharmacylocations";
		
	}

	@RequestMapping(value = "/fremontPharmacyList", method = RequestMethod.POST)
	public String fremontPharmacy (){
		return "fremontpharmacy";
		
	}
	@RequestMapping(value = "/cupertinoPharmacyList", method = RequestMethod.POST)
	public String cupertinoPharmacy (){
		return "cupertinopharmacy";
		
	}
	
	@RequestMapping(value = "/losangelesPharmacyList", method = RequestMethod.POST)
	public String losangelesPharmacy (){
		return "losangelespharmacy";
		
	}
	@RequestMapping(value = "/sanfransiscoPharmacyList", method = RequestMethod.POST)
	public String sanfransiscoPharmacy (){
		return "sanfransiscopharmacy";
		
	}
	@RequestMapping(value = "/sunnyvalePharmacyList", method = RequestMethod.POST)
	public String sunnyvalePharmacy (){
		return "sunnyvalepharmacy";
		
	}
	
	@RequestMapping(value = "/beautysalon", method = RequestMethod.POST)
	public String findsalonLocation (){
		return "salonlocations";
		
	}
	
	@RequestMapping(value = "/fremontSalonList", method = RequestMethod.POST)
	public String fremontSalon (){
		return "fremontsalon";
		
	}
	@RequestMapping(value = "/cupertinoSalonList", method = RequestMethod.POST)
	public String cupertinoSalon (){
		return "cupertinosalon";
		
	}
	
	@RequestMapping(value = "/losangelesSalonList", method = RequestMethod.POST)
	public String losangelesSalon (){
		return "losangelessalon";
		
	}
	@RequestMapping(value = "/sanfransiscoSalonList", method = RequestMethod.POST)
	public String sanfransiscoSalon (){
		return "sanfransiscosalon";
		
	}
	@RequestMapping(value = "/sunnyvaleSalonList", method = RequestMethod.POST)
	public String sunnyvaleSalon (){
		return "sunnyvalesalon";
		
	}
	@RequestMapping(value = "/machineatm", method = RequestMethod.POST)
	public String findatmLocation (){
		return "atmlocations";
		
	}
	@RequestMapping(value = "/fremontAtmList", method = RequestMethod.POST)
	public String fremontAtm (){
		return "fremontatm";
		
	}
	@RequestMapping(value = "/cupertinoAtmList", method = RequestMethod.POST)
	public String cupertinoAtm (){
		return "cupertinoatm";
		
	}
	
	@RequestMapping(value = "/losangelesAtmList", method = RequestMethod.POST)
	public String losangelesAtm (){
		return "losangelesatm";
		
	}
	@RequestMapping(value = "/sanfransiscoAtmList", method = RequestMethod.POST)
	public String sanfransiscoAtm (){
		return "sanfransiscoatm";
		
	}
	@RequestMapping(value = "/sunnyvaleAtmList", method = RequestMethod.POST)
	public String sunnyvaleAtm (){
		return "sunnyvaleatm";
		
	}
	

	@RequestMapping(value = "/fremontHospitalList", method = RequestMethod.POST)
	public String fremontHospital (){
		return "fremonthospital";
		
	}
	@RequestMapping(value = "/cupertinoHospitalList", method = RequestMethod.POST)
	public String cupertinoHospital (){
		return "cupertinohospital";
		
	}
	
	@RequestMapping(value = "/losangelesHospitalList", method = RequestMethod.POST)
	public String losangelesHospital (){
		return "losangeleshospital";
		
	}
	@RequestMapping(value = "/sanfransiscoHospitalList", method = RequestMethod.POST)
	public String sanfransiscoHospital (){
		return "sanfransiscohospital";
		
	}
	@RequestMapping(value = "/sunnyvaleHospitalList", method = RequestMethod.POST)
	public String sunnyvaleHospital (){
		return "sunnyvalehospital";
		
	}
	@RequestMapping(value = "/hospitalplace", method = RequestMethod.POST)
	public String findhospitalLocation (){
		return "hospitallocations";
		
	}
	
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registrationForm(ModelMap model) {
		RegistrationForm regform = new RegistrationForm();
		model.addAttribute("regform", regform);
		return "registration";

	} 
	
	@RequestMapping(value = "/registrationsuccess", method = RequestMethod.POST)
	public String getRegistrationForm(@ModelAttribute("regform") @Valid RegistrationForm  regform, BindingResult result, ModelMap model) {
       
		System.out.println("The name is : " + regform.getFirstName());
		System.out.println("The Password is : " + regform.getState());
		System.out.println("I am here in registration!!");
		if (result.hasErrors()) {
			return "registration";
		}
		RegistrationService registrationService = new RegistrationService();
		regform.setFirstName(regform.getFirstName());
		regform.setLastName(regform.getLastName());
		regform.setUserName(regform.getUserName());
		regform.setPassword(regform.getPassword());
		regform.setStreetAddress(regform.getStreetAddress());
		regform.setCity(regform.getCity());
		regform.setState(regform.getState());
		regform.setZipCode(regform.getZipCode());
		registrationService.saveRegistrationDetails(regform);
		return "success";

	}
	
}
