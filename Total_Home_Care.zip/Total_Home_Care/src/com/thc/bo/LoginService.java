package com.thc.bo;


import java.sql.Connection;

import java.sql.ResultSet;


import com.mysql.jdbc.Statement;
import com.thc.dao.DatabaseDAO;
import com.thc.vo.LoginForm;



public class LoginService implements LoginServiceInterface{

	public int checkLogin(LoginForm lform){
		int status = 0;
	    Statement stmt = null;
		try {
			
			@SuppressWarnings("unused")
			DatabaseDAO databasedao = new DatabaseDAO();
			Connection dbConn = DatabaseDAO.getConnection();
			String lusername = lform.getUsername();
			String lpassword = lform.getPassword();
			 stmt = (Statement) dbConn.createStatement();
			 System.out.println("I am in lOGIN");
			String sql = "SELECT username, password, zipcode FROM customerinfo";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			// STEP 5: Extract data from result set
			
			//System.out.print("This is lform Username: " + lusername);
			//System.out.print("This is lform Password: " + lpassword);

			while (rs.next()) {

				// Retrieve by column name
				String username = rs.getString("username");
				String password = rs.getString("password");
				String zipcode = rs.getString("zipcode");
				if(username.equals(lusername) && password.equals(lpassword))
				{
					System.out.println(zipcode);
					status = 1;
				}
				
			} 
		
		}catch (Exception e) 
			{
			
			//message : // incorrect username or password
		  e.printStackTrace();
			
		}
		
		return status;
		
	}


}
