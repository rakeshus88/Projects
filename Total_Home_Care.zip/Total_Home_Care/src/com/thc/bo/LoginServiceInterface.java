package com.thc.bo;


import com.thc.vo.LoginForm;

public interface LoginServiceInterface {
	
	public int checkLogin(LoginForm lform);

	
}
