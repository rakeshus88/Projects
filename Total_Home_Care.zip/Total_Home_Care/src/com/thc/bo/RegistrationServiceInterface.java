package com.thc.bo;

import com.thc.vo.RegistrationForm;

public interface RegistrationServiceInterface {
	public void saveRegistrationDetails(RegistrationForm regform);

}
