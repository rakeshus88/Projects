package com.thc.bo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.thc.dao.DatabaseDAO;
import com.thc.vo.RegistrationForm;

public class RegistrationService implements RegistrationServiceInterface{

	@Override
	public void saveRegistrationDetails(RegistrationForm regform) {
		
		Connection dbConn = null;
	    PreparedStatement ps = null;
    	String sql = "INSERT INTO customerinfo " +
                "(firstname, lastname, username, password, streetAddress, state, city, zipcode ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			
			@SuppressWarnings("unused")
			DatabaseDAO databasedao = new DatabaseDAO();
			 dbConn = DatabaseDAO.getConnection();
			System.out.println("Hi i am deepthy inside registration service");
			
		
			//validation
			System.out.println("hi ai ma displaying sql " +sql);
			ps = dbConn.prepareStatement(sql);
			ps.setString(1, regform.getFirstName());
			ps.setString(2, regform.getLastName());
			ps.setString(3, regform.getUserName());
			ps.setString(4, regform.getPassword());
			ps.setString(5, regform.getStreetAddress());
			ps.setString(6, regform.getState());
			ps.setString(7, regform.getCity());
			ps.setInt(8, regform.getZipCode());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (dbConn != null) {
				try {
					dbConn.close();
				} catch (SQLException e) {}
			}
		}
	}

}
