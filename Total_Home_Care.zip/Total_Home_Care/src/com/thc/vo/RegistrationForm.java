package com.thc.vo;


import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotEmpty;

public class RegistrationForm {
	public RegistrationForm() {
		super();
	}
	
	@NotEmpty(message = "Please enter your firstName.")
	private String firstName;
	@NotEmpty(message = "Please enter your lastName.")
	private String lastName;
	@NotEmpty(message = "Please enter StreetAddres.")
	private String streetAddress;
	private String city;
	 @Digits(integer = 5, message="Please enter 5 digits", fraction = 0)
	 @NotNull(message = "Please enter Zipcode.")
	private int zipCode;
	private String state;
	@NotEmpty(message = "Username is mandatory.")
	private String userName;
	@NotEmpty(message = "Password is mandatory.")
	private String password;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
