package com.thc.vo;

import org.hibernate.validator.constraints.NotEmpty;

public class LoginForm {
	public LoginForm() {
		super();
	}

	@NotEmpty(message = "Please enter your username.")
	private String username;

	@NotEmpty(message = "Please enter your password.")
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
