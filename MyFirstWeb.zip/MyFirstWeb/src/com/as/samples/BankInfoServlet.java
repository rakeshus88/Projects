package com.as.samples;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.as.samples.bo.RegistrationBO;
import com.as.samples.dao.RegistrationDAO;
import com.as.samples.validation.BaseValidations;
import com.as.samples.validation.Validations;
import com.as.samples.valueobject.BankInfo;
import com.as.samples.valueobject.ContactInfo;
import com.as.samples.valueobject.PersonalInfo;

public class BankInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		int userId;
		BankInfo bankInfo = new BankInfo();
		bankInfo.setBankName(request.getParameter("banknm"));
		bankInfo.setAccount(request.getParameter("account"));
		bankInfo.setSsn(request.getParameter("ssn"));

		HttpSession session = request.getSession();
		session.setAttribute("binfo", bankInfo);
		// Route to BO
		error = RegistrationBO.bankDetails(session, error);

		if (BaseValidations.isBlank(error)) {
			response.sendRedirect("jsp/successJSTL.jsp");
		} else {
			request.setAttribute("errorMessages", error);
			RequestDispatcher rd = request.getRequestDispatcher("jsp/bankinfoJSTL.jsp");
			rd.forward(request, response);// method may be include or forward
		}

	}

}
