package com.as.samples;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.as.samples.bo.RegistrationBO;
import com.as.samples.validation.BaseValidations;
import com.as.samples.validation.Validations;
import com.as.samples.valueobject.ContactInfo;
import com.as.samples.valueobject.Registration;

public class ContactInfoServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		ContactInfo contactInfo = new ContactInfo();
		contactInfo.setAddress(request.getParameter("address"));
		contactInfo.setCity(request.getParameter("city"));
		contactInfo.setState(request.getParameter("state"));
		contactInfo.setCountry(request.getParameter("country"));
		contactInfo.setPhone(request.getParameter("phone"));

		
		HttpSession session = request.getSession();
		session.setAttribute("coninfo", contactInfo);
		// Route to BO
			error = RegistrationBO.contactDetails(session, error);

		if (BaseValidations.isBlank(error)) {
			// response.sendRedirect("jsp/bankinfo.jsp");
			response.sendRedirect("jsp/bankinfoJSTL.jsp");
		} else {
			request.setAttribute("errorMessages", error);
			RequestDispatcher rd = request.getRequestDispatcher("jsp/contactinfoJSTL.jsp");
			rd.forward(request, response);// method may be include or forward
		}

	}

}
