package com.as.samples;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CalculatorServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String inp1 = request.getParameter("int1");
		String inp2 = request.getParameter("int2");
		String operation = request.getParameter("submit");
		int result = 0;
		System.out.println("The operation is :" + operation);

		if (operation.trim().equalsIgnoreCase("Add")) {
			result = Integer.parseInt(inp1) + Integer.parseInt(inp2);
			System.out.println(result);
		}
		if (operation.trim().equalsIgnoreCase("Subtract")) {
			result = Integer.parseInt(inp1) - Integer.parseInt(inp2);
		}
		if (operation.trim().equalsIgnoreCase("Multiply")) {
			result = Integer.parseInt(inp1) * Integer.parseInt(inp2);
		}
		if (operation.trim().equalsIgnoreCase("Divide")) {
			result = Integer.parseInt(inp1) / Integer.parseInt(inp2);
		}
		if (operation.trim().equalsIgnoreCase("Reset")) {
			response.sendRedirect("html/calculatorDemo.html");
		}
		System.out.println("The value of result is : " + result);
		HttpSession sess = request.getSession();
		sess.setAttribute("int1", inp1);
		sess.setAttribute("int2", inp2);
		sess.setAttribute("result", Integer.toString(result));

		response.sendRedirect("jsp/outputCalulator.jsp");
	}

}
