package com.as.samples.bo;

import javax.servlet.http.HttpSession;

import com.as.samples.dao.RegistrationDAO;
import com.as.samples.validation.BaseValidations;
import com.as.samples.validation.Validations;
import com.as.samples.valueobject.BankInfo;
import com.as.samples.valueobject.ContactInfo;
import com.as.samples.valueobject.PersonalInfo;

public class RegistrationBO {
	
	public static String personalDetails(HttpSession session, String error) {

		// Validations:
		error = Validations.validatePersonalInfo((PersonalInfo) session.getAttribute("pinfo"), error);
		return error;
	}
	
	public static String contactDetails(HttpSession session, String error) {
		// Validations
				error = Validations.validateContactInfo((ContactInfo) session.getAttribute("coninfo"), error);
		return error;
	}

	public static String bankDetails(HttpSession session, String error) {
		// Validations
		error = Validations.validateBankInfo((BankInfo) (session.getAttribute("binfo")), error);
		// dB insert
		int userId;
		if (BaseValidations.isBlank(error)) {
		
			RegistrationDAO regDao = new RegistrationDAO();
			try {
				userId = regDao.getUserId();
				userId++;
				regDao.insertPirsonalInfo((PersonalInfo) session.getAttribute("pinfo"), userId);
				regDao.insertContactInfo((ContactInfo) session.getAttribute("coninfo"), userId);
				regDao.insertBankInfo((BankInfo) session.getAttribute("binfo"), userId);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return error;
	}
	
}
