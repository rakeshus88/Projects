package com.as.samples.validation;

public class BaseValidations {

	public static boolean isBlank(String field) {
		return ((field == null || field.trim().length() == 0));
	}

	public static boolean hasMinLength(String field) {
		return (field != null && field.trim().length() >= 2);
	}

	public static boolean checkCharacterSet(String field) {
		return field.matches("^[\\p{L} .'-]+$");
	}
	
	public static boolean checkCharacter(String field) {
		return field.matches("[a-zA-Z]");
	} 
	
	public static boolean checkNumbers(String field) {
		return field.matches("\\d+");
	}

}
