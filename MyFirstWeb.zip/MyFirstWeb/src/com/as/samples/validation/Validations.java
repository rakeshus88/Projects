package com.as.samples.validation;

import com.as.samples.valueobject.BankInfo;
import com.as.samples.valueobject.ContactInfo;
import com.as.samples.valueobject.PersonalInfo;

public class Validations {

	public static String validatePersonalInfo(PersonalInfo personalInfo, String errors) {
		if (BaseValidations.isBlank(personalInfo.getFirstName())) {
			errors += "First Name cannot be blank<br/>";
		} else if (!(BaseValidations.hasMinLength(personalInfo.getFirstName()))
				|| !(BaseValidations.checkCharacterSet(personalInfo.getFirstName()))) {
			errors += "Invalid first name<br/>";
		}
		if (personalInfo.getMiddleName() != null && !(BaseValidations.isBlank(personalInfo.getMiddleName())))
			if (!(BaseValidations.checkCharacterSet(personalInfo.getMiddleName()))) {
				errors += "Invalid Middle Name<br/>";
			}
		if (BaseValidations.isBlank(personalInfo.getLastName())) {
			errors += "Last Name cannot be blank<br/>";
		} else if (!(BaseValidations.hasMinLength(personalInfo.getLastName()))
				|| !(BaseValidations.checkCharacterSet(personalInfo.getLastName()))) {
			errors += "Invalid Last Name<br/>";
		}

		return errors;
	}

	public static String validateContactInfo(ContactInfo contactInfo, String errors) {
		if (BaseValidations.isBlank(contactInfo.getAddress())) {
			errors += "Address cannot be blank<br/>";
		} else if (!(BaseValidations.hasMinLength(contactInfo.getAddress()))
				|| !(contactInfo.getAddress().matches("^[a-zA-Z0-9][a-zA-Z0-9 ]*$"))) {
			errors += "Invalid Address<br/>";
		}
		if (BaseValidations.isBlank(contactInfo.getCity())) {
			errors += "City cannot be blank<br/>";
		} else if (!contactInfo.getCity().matches("^[a-zA-Z0-9][a-zA-Z0-9 ]*$")) {
			errors += "Invalid city<br/>";
		}
		if (BaseValidations.isBlank(contactInfo.getState())) {
			errors += "State cannot be blank<br/>";
		} else if (!(contactInfo.getState().matches("^[a-zA-Z0-9][a-zA-Z0-9 ]*$"))) {
			errors += "Invalid state<br/>";
		}
		if (BaseValidations.isBlank(contactInfo.getCountry())) {
			errors += "Country not selected<br/>";
		}
		if (BaseValidations.isBlank(contactInfo.getPhone())) {
			errors += "Phone number cannot be blank<br/>";
		} else if (!contactInfo.getPhone().matches("\\d{10}")) {
			errors += "Invalid phone number<br/>";
		}
		return errors;
	}

	public static String validateBankInfo(BankInfo bankInfo, String errors) {
		if (BaseValidations.isBlank(bankInfo.getBankName())) {
			errors += "Please select the Bank Name<br/>";
		}
		if (BaseValidations.isBlank(bankInfo.getAccount())) {
			errors += "Account Number cannot be blank<br/>";
		} else if (!(BaseValidations.checkNumbers((bankInfo.getAccount())))) {
			errors += "Invalid Account Number<br/>";
		}
		if (BaseValidations.isBlank(bankInfo.getSsn())) {
			errors += "SSN cannot be blank<br/>";
		} else if (!(bankInfo.getSsn().matches("^\\d{3}[- ]?\\d{2}[- ]?\\d{4}$"))) {
			errors += "Invalid SSN number<br>";
		}
		return errors;
	}
}
