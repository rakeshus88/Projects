package com.as.samples.valueobject;

public class Registration {
	private Object beans;

	public Registration() {
		super();
	}

	public Object getBeans() {
		return beans;
	}

	public void setBeans(Object beans) {
		this.beans = beans;
	}

}
