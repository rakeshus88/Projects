package com.as.samples;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Welcome2Servelet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("fname");
		String middleName = request.getParameter("mname");
		String lastName = request.getParameter("lname");
		HttpSession session = request.getSession();
		session.setAttribute("fn", firstName);
		session.setAttribute("mn", middleName);
		session.setAttribute("ln", lastName);
		response.sendRedirect("jsp/welcome2Output.jsp");
	}

}
