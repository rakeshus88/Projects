package com.as.samples.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.as.samples.valueobject.BankInfo;
import com.as.samples.valueobject.ContactInfo;
import com.as.samples.valueobject.PersonalInfo;

public class RegistrationDAO {

	// Getting Connection

	public static Connection getConnection() throws Exception {
		Connection dbConn = null;
		try {
			// step1:
			Class.forName("com.mysql.jdbc.Driver");
			// step2
			String url = "jdbc:mysql://localhost:3306/test";

			// step3
			dbConn = DriverManager.getConnection(url, "root", "");
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return dbConn;
	}

	// get the last entry for user id
//	public int getUserId() throws Exception {
//		Connection dbConn = null;
//		PreparedStatement pStmt = null;
//		ResultSet rs = null;
//		int lastUserid = 0;
//
//		try {
//			dbConn = getConnection();
//			
//			pStmt = dbConn.prepareStatement("SELECT MAX(userid) FROM userinfo");
//
//			rs = pStmt.executeQuery();
//			if (rs.next()) {
//				System.out.println(rs.getInt(1));
//				lastUserid = rs.getInt(1);
//			}
//		} catch (SQLException sqe) {
//			// log the error
//			sqe.printStackTrace();
//			// throw the exception
//			throw sqe;
//		} finally {
//			rs.close();
//			pStmt.close();
//			dbConn.close();
//		}
//		return lastUserid;
//	}
//
//	// Insert user personal info
//	public void insertPirsonalInfo(PersonalInfo attribute, int userId) throws Exception {
//		Connection dbConn = null;
//		PreparedStatement pStmt = null;
//		int rowsInserted = 0;
//
//		try {
//			dbConn = getConnection();
//			pStmt = dbConn.prepareStatement(
//					"INSERT INTO `userinfo`(`userid`, `firstname`, `lastname`, `middlename`, `gender`) VALUES (?, ?, ?,?,?)");
//			pStmt.setInt(1, userId);
//			pStmt.setString(2, attribute.getFirstName());
//			pStmt.setString(3, attribute.getLastName());
//			pStmt.setString(4, attribute.getMiddleName());
//			pStmt.setString(5, attribute.getGender());
//
//			rowsInserted = pStmt.executeUpdate();
//
//			if (rowsInserted != 1) {
//				throw new Exception("Error in inserting the row");
//
//			}
//		} catch (SQLException sqle) {
//			System.out.println(sqle.getErrorCode());
//			System.out.println(sqle.getMessage());
//			sqle.printStackTrace();
//			throw sqle;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			pStmt.close();
//			dbConn.close();
//		}
//		return;
//
//	}
//
//	public void insertContactInfo(ContactInfo attribute, int userId) throws Exception {
//		Connection dbConn = null;
//		PreparedStatement pStmt = null;
//		int rowsInserted = 0;
//
//		try {
//			dbConn = getConnection();
//			pStmt = dbConn.prepareStatement(
//					"INSERT INTO `contactdetails`(`userid`, `address`, `city`, `state`, `country`, `phone`) VALUES (?, ?, ?,?,?,?)");
//			pStmt.setInt(1, userId);
//			pStmt.setString(2, attribute.getAddress());
//			pStmt.setString(3, attribute.getCity());
//			pStmt.setString(4, attribute.getState());
//			pStmt.setString(5, attribute.getCountry());
//			pStmt.setString(6, attribute.getPhone());
//			rowsInserted = pStmt.executeUpdate();
//
//			if (rowsInserted != 1) {
//				throw new Exception("Error in inserting the row");
//
//			}
//		} catch (SQLException sqle) {
//			System.out.println(sqle.getErrorCode());
//			System.out.println(sqle.getMessage());
//			sqle.printStackTrace();
//			throw sqle;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			pStmt.close();
//			dbConn.close();
//		}
//		return;
//
//	}
//
//	public void insertBankInfo(BankInfo attribute, int userId) throws Exception {
//		Connection dbConn = null;
//		PreparedStatement pStmt = null;
//		int rowsInserted = 0;
//
//		try {
//			dbConn = getConnection();
//			pStmt = dbConn.prepareStatement(
//					"INSERT INTO `bankdetails`(`userid`, `bankName`, `Account`, `ssn`) VALUES (?, ?, ?,?)");
//			pStmt.setInt(1, userId);
//			pStmt.setString(2, attribute.getBankName());
//			pStmt.setString(3, attribute.getAccount());
//			pStmt.setString(4, attribute.getSsn());
//
//			rowsInserted = pStmt.executeUpdate();
//
//			if (rowsInserted != 1) {
//				throw new Exception("Error in inserting the row");
//
//			}
//		} catch (SQLException sqle) {
//			System.out.println(sqle.getErrorCode());
//			System.out.println(sqle.getMessage());
//			sqle.printStackTrace();
//			throw sqle;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			pStmt.close();
//			dbConn.close();
//		}
//		return;
//
//	}

}
